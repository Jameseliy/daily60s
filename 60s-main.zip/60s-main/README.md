# 60s

每天 60 秒读懂世界

数据接口: `https://60s.viki.moe/60s?v2=1`

## 参考资料
- [https://niracler.com/nyaruko-deploy-for-xlog](https://niracler.com/nyaruko-deploy-for-xlog)
- [https://blog.ijust.cc/play-xlog-02](https://blog.ijust.cc/play-xlog-02)
- [https://crossbell.js.org](https://crossbell.js.org)
